from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

from . import views

app_name = "remanga"
urlpatterns = [
    path("", views.CatalogView.as_view(), name="catalog"),
    path("manga/<str:dir_name>/", views.TitleView.as_view(), name="title"),
    path("search/", views.SearchView.as_view(), name="search"),
]
