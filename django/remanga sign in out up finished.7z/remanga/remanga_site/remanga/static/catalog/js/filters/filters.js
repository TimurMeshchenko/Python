class Filters {

  main(data_array) {
    new Drop_menu_filters(data_array);
    new Input_range_filters();
    new Chapters_filters();
  }
}