// var button = document.querySelectorAll(".Button_button__JOS9_.Tab_root__aAqqc");
// var description = document.querySelector(".px-4.py-2").innerHTML;

// button[0].addEventListener("click", function () {
//   document.querySelector(".px-4.py-2").innerHTML = description;
// });

// button[1].addEventListener("click", chapter_switch);

// function chapter_switch() {
//   document.querySelector(".px-4.py-2").innerHTML = `  
//   <div class="Chapters_container__G5BYo">
//     <div class="Chapters_container__G5BYo">
//       {% for chapter in title.chapters.all %}
//       <div class="Chapters_chapterItem__z8nrU flex items-center">
//         <span class="Chapters_tome__VAir6">{{ chapter.tome }}</span
//         ><a
//           class="Chapters_content__lYYd5 flex items-center"
//           href="/manga/the_beginning_after_the_end/721795"
//           ><p
//             class="Typography_body1__TZSwE Typography_color-inherit__bgLyK Chapters_title__Jsy0U"
//           >
//             Глава {{ chapter.chapter }} 
//           </p>
//         </a>
//       </div>
//       {% endfor %}
//     </div>
//   </div>
//   `;
// }
