from django.contrib import admin

from .models import Title

admin.site.register(Title)
