class Filter_menu {
  constructor(data, input_number, value_key, type_name) {
    this.filter_data = JSON.parse(data);
    this.input_number = input_number;
    this.value_key = value_key;
    this.type_name = type_name;
    this.get_elements();
    // this.classes_init();
    // this.url = window.location.href;
  }

  get_elements() {
    this.div_input = document.querySelectorAll(".jsx-d338f3d1a4c6e9b5")[
      this.input_number
    ];
    this.input = document.querySelectorAll(".jsx-1d2861d85dfb4f6f")[
      this.input_number
    ];
    this.all_filter_span = [
      ...document.querySelectorAll(".jsx-1b57bf17c694e838"),
    ];
    this.div_label = document.querySelectorAll(".jsx-df39090361a5f2e4")[
      this.input_number
    ];
    this.filter_menu_class = ".jsx-f6904a6ed8e0085";
    this.filter_menu = document.querySelector(this.filter_menu_class);
  }

  // classes_init() {
  //   this.stylization_filter_menu = new Stylization_filter_menu(
  //     this.type_name,
  //     this.input_number,
  //     this.get_elements
  //   );

  //   this.url_requests = new Url_requests(
  //     this.get_elements,
  //     this.type_name,
  //     this.input_number
  //   );
  // }

  create_filter_menu() {
    var div_input_html = this.div_input.innerHTML;

    const click_anywhere = (event) => {
      this.determine_location_click(event, div_input_html);
    };

    document.querySelector("html").addEventListener("click", click_anywhere);

    // this.call_translate_url();
    // this.url_requests.listen_input_range();
    // this.url_requests.listen_chapters_spans();
    // new Input_focus().urls_compare();
    // this.restore_dropdown();
  }

  determine_location_click(event, div_input_html) {
    let parent_clicked_element = event.target.outerHTML;
    this.get_elements();

    const check_repeat_click = () => {
      if (!this.div_input.querySelector(this.filter_menu_class)) {
        this.showDropdown();
      }
    };

    if (event.target.innerHTML == "×") {
      // this.url_requests.delete_filter(event, this.filter_data, this.value_key);
      return;
    }

    if (this.all_filter_span.includes(event.target)) {
      return;
    }

    if (event.target.tagName == "INPUT") {
      parent_clicked_element = event.target.parentNode.outerHTML;
    }

    if (this.div_label.parentNode.outerHTML.includes(parent_clicked_element)) {
      check_repeat_click();
    } else {
      this.div_input.innerHTML = div_input_html;
      // this.call_translate_url();
    }
  }

  // call_translate_url() {
  //   this.stylization_filter_menu.translate_url(
  //     this.filter_data,
  //     this.value_key
  //   );
  // }

  // restore_dropdown() {
  //   if (this.url.split("&").pop().includes(this.type_name)) {
  //     if (localStorage.getItem("input_number") != null) {
  //       if (
  //         this.input_number === Number(localStorage.getItem("input_number"))
  //       ) {
          
  //         // СПОСОБ различать блок фильтрации исключений от обычного

  //         // let div_inputs = document.querySelectorAll(".jsx-d338f3d1a4c6e9b5");
  //         // let parent_divs_active = document.activeElement.parentNode.parentNode.parentNode.parentNode;
  //         // let filter_title_class = "flex"

  //         // if(parent_divs_active.previousElementSibling.className.includes(
  //         //     filter_title_class
  //         //   )) {
  //         //     let count_div_first_block = 3
  //         //     for (
  //         //       let index_div_input = 0;
  //         //       index_div_input < count_div_first_block;
  //         //       index_div_input++
  //         //     ) {
  //         //       if(
  //         //         div_inputs[index_div_input].innerHTML.includes(
  //         //           document.activeElement.outerHTML
  //         //         )
  //         //       ) {
  //         //     };
  //         //   }
  //         // }

  //         this.showDropdown();

  //         this.get_elements();

  //         this.filter_menu.scrollTo(
  //           0,
  //           Number(localStorage.getItem("div_span_scroll"))
  //         );
  //         // localStorage.clear();
  //       }
  //     }
  //   }
  // }

  showDropdown() {
    this.div_input.innerHTML += `
      <div
        tabindex="-1"
        aria-expanded="true"
        role="list"
        class="jsx-f6904a6ed8e0085 jsx-2945355907 select-dropdown"
      >
      `;

    this.get_elements();
    const empty_filter_menu = this.filter_menu.innerHTML;

    this.filter_data.map((info) => {
      this.filter_menu_content(info[this.value_key]);
    });

    // this.call_after_showDropdown(empty_filter_menu);
  }

  filter_menu_content(value) {
    this.filter_menu.innerHTML += `
        <span
        role="option"
        aria-selected="false"
        aria-label="${value}"
        tabindex="-1"
        class="jsx-1b57bf17c694e838"
        >${value}
      </span>
        `;
  }

  // call_after_showDropdown(empty_filter_menu) {
  //   this.get_elements();
  //   this.input.focus();

    // // this.call_translate_url();
    // this.search(empty_filter_menu);
    // // this.url_requests.listen_span_click();
    // // this.stylization_filter_menu.change_filter_menu_height();
  // }

  // search(empty_filter_menu) {
  //   this.get_elements();
  //   let filteredArr = [];
  //   let item_selected = document.querySelectorAll(".item-selected");

  //   this.input.addEventListener("keyup", (event) => {
  //     this.filter_menu.innerHTML = empty_filter_menu;
  //     filteredArr = this.filter_data.filter((info) =>
  //       info[this.value_key]
  //         .toLowerCase()
  //         .includes(event.target.value.toLowerCase())
  //     );
  //     if (filteredArr.length) {
  //       filteredArr.map((info) => {
  //         this.filter_menu_content(info[this.value_key]);
  //       });
  //     }
  //     // this.stylization_filter_menu.search_color_span(item_selected);
  //   });
  // }
  //
}
