class Stylization_filter_menu {
  constructor(type_name, input_number, get_elements) {
    this.type_name = type_name;
    this.input_number = input_number;
    this.get_elements = get_elements;
    this.get_elements();
  }
  // chapters_filters

  init_chapters_vars() {
    this.chapters_gte = "count_chapters_gte";
    this.chapters_lte = "count_chapters_lte";
    this.url_chapters_range_map = {
      [this.chapters_gte]: "",
      [this.chapters_lte]: "",
    };
    this.all_chapters_range_map = Object.assign(
      {},
      this.url_chapters_range_map
    );
    this.last_url_search_map = Object.assign({}, this.url_chapters_range_map);
    this.last_chapters_range_map = JSON.parse(
      localStorage.getItem("last_chapters_range_map")
    );
  }
  //
  translate_url(filter_data, value_key) {
    const url_search = window.location.search.replace("?", "");
    this.init_chapters_vars();

    for (let url_part of url_search.split("&")) {
      let url_part_value = url_part.replace(/\D/g, "");

      if (url_part.includes(this.type_name)) {
        this.color_clicked_span(url_part_value);
        this.add_label_input(filter_data, value_key, url_part_value);
      }

      this.color_chapters_by_url(url_part, url_part_value);
    }

    this.remove_placeholder();
  }
  // dropmenu_filters
  color_clicked_span(type_value) {
    this.get_elements();
    if (this.filter_menu) {
      if (this.input_number == this.get_index_filter_menu()) {
        this.all_filter_span[type_value].classList.add("item-selected");
      }
    }
  }

  get_index_filter_menu() {
    if (this.div_input.querySelector(this.filter_menu_class)) {
      return this.input_number;
    }
  }

  add_label_input(filter_data, value_key, type_value) {
    const type_value_array = [];
    const label_class = ".select-option";
    const max_count_labels = 6;

    const existingLabels = this.div_label.querySelectorAll(label_class);
    if (existingLabels.length >= max_count_labels) {
      return;
    }

    for (const info of filter_data) {
      type_value_array.push(info[value_key]);
    }

    const typeValue = type_value_array[type_value];
    if (!this.div_label.innerHTML.includes(typeValue)) {
      this.div_label.insertAdjacentHTML(
        "afterbegin",
        `
      <span role="listitem" class="jsx-9f9056eddaf3b30b select-option">
        <span class="jsx-9f9056eddaf3b30b">${typeValue}</span>
        <span class="jsx-9f9056eddaf3b30b select-option-remove">×</span>
      </span>
    `
      );
    }
  }

  remove_placeholder() {
    const label_class = "select-option";
    if (this.div_label.innerHTML.includes(label_class)) {
      this.input.placeholder = "";
    }
  }

  change_filter_menu_height() {
    this.get_elements();
    this.filter_menu.style["top"] =
      String(this.div_label.offsetHeight + 2) + "px";
  }

  search_color_span(item_selected) {
    this.get_elements();

    this.all_filter_span.forEach((span) => {
      item_selected.forEach((selected) => {
        if (span.ariaLabel === selected.ariaLabel) {
          span.classList.add("item-selected");
        }
      });
    });
  }
  //
  // chapters_filters

  color_chapters_by_url(url_part, url_part_value) {
    //update_chapters_maps
    if (url_part.includes(this.chapters_gte)) {
      this.url_chapters_range_map[this.chapters_gte] = url_part_value;
    }

    if (!url_part.includes(this.chapters_lte)) {
      return;
    }

    this.url_chapters_range_map[this.chapters_lte] = url_part_value;
    const chapters_spans = [...document.querySelectorAll(".Chip_chip__cpsxK")];

    for (let chapter_span of chapters_spans) {
      let chapter_span_text = chapter_span.innerText;
      let chapter_span_values_array = chapter_span_text.match(/\d+/g);

      const update_all_chapters_range_map = (symbol, map_key) => {
        if (chapter_span_text.includes(symbol)) {
          this.all_chapters_range_map[map_key] = chapter_span_values_array[0];
          if (symbol == "-") {
            this.all_chapters_range_map[this.chapters_lte] =
              chapter_span_values_array[1];
          }
          if (symbol == ">") {
            this.all_chapters_range_map[this.chapters_lte] = "";
          }
        }
      };

      update_all_chapters_range_map("<", this.chapters_lte);
      update_all_chapters_range_map("-", this.chapters_gte);
      update_all_chapters_range_map(">", this.chapters_gte);

      this.update_last_url_search_map();

      this.create_color_chapters_by_url_condition(chapter_span);
    }
  }

  update_last_url_search_map() {
    const last_url_search = localStorage.getItem("last_url_search");
    if (
      this.last_chapters_range_map[this.chapters_gte] == "50" &&
      this.last_chapters_range_map[this.chapters_lte] == String()
    ) {
      this.last_chapters_range_map[this.chapters_gte] = String();
      this.last_chapters_range_map[this.chapters_lte] = "50";
    }

    for (let url_part of last_url_search.split("&")) {
      let url_part_value = url_part.replace(/\D/g, "");

      if (url_part.includes(this.chapters_gte)) {
        this.last_url_search_map[this.chapters_gte] = url_part_value;
      }
      if (url_part.includes(this.chapters_lte)) {
        this.last_url_search_map[this.chapters_lte] = url_part_value;
      }
    }
  }

  create_color_chapters_by_url_condition(chapter_span) {
    const chapter_class_gray = "Chip_gray__uE26d";
    const chapter_class_blue = "Chip_primary__AHVQ0";

    const color_chapter_span = () => {
      chapter_span.className = chapter_span.className.replace(
        chapter_class_gray,
        chapter_class_blue
      );
    };

    const color_chapters_by_url_condition = (condition) => {
      if (condition) {
        color_chapter_span();
      }
    };

    this.call_color_chapters_by_url_condition(color_chapters_by_url_condition);
  }

  call_color_chapters_by_url_condition(color_chapters_by_url_condition) {
    let all_chapters_map_values = Object.values(this.all_chapters_range_map);
    let url_chapters_map_values = Object.values(this.url_chapters_range_map);
    let is_url_chapter_lte_gte_div =
      Number(url_chapters_map_values[1]) >= Number(all_chapters_map_values[1]);
    let is_url_chapter_gte_lte_div =
      Number(url_chapters_map_values[0]) <= Number(all_chapters_map_values[0]);
    // <50
    color_chapters_by_url_condition(
      is_url_chapter_lte_gte_div &&
        all_chapters_map_values[1] !== String() &&
        url_chapters_map_values[0] == String()
    );
    // >200
    color_chapters_by_url_condition(
      is_url_chapter_gte_lte_div &&
        all_chapters_map_values[0] !== String() &&
        url_chapters_map_values[1] == String() &&
        JSON.stringify(this.last_url_search_map) !==
          JSON.stringify(this.last_chapters_range_map)
    );
    // 50-100, 100-200
    color_chapters_by_url_condition(
      is_url_chapter_gte_lte_div &&
        is_url_chapter_lte_gte_div &&
        all_chapters_map_values[1] !== String() &&
        url_chapters_map_values[0] !== String()
    );
    // Все
    color_chapters_by_url_condition(
      url_chapters_map_values[0] == url_chapters_map_values[1] &&
        JSON.stringify(this.last_url_search_map) !==
          JSON.stringify(this.last_chapters_range_map)
    );
    // Первый клик
    color_chapters_by_url_condition(
      JSON.stringify(all_chapters_map_values) ==
        JSON.stringify(url_chapters_map_values)
    );
    // console.log(this.last_url_search_map, this.last_chapters_range_map);
  }
  //
}
