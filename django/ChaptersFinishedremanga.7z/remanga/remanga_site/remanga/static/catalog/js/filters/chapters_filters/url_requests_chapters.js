class Url_requests_chapters {
  constructor(init_url_vars) {
    this.init_url_vars = init_url_vars;
    this.init_url_vars();
  }
  // chapters_filters

  call_add_url_chapter_request(clicked_text) {
    const value_range_array = clicked_text.match(/\d+/g);

    let last_chapters_range_map = {
      count_chapters_gte:
        value_range_array[0] == undefined ? String() : value_range_array[0],
      count_chapters_lte:
        value_range_array[1] == undefined ? String() : value_range_array[1],
    };
    localStorage.setItem(
      "last_chapters_range_map",
      JSON.stringify(last_chapters_range_map)
    );

    const update_chapters_range_map = (symbol, map_key) => {
      if (clicked_text.includes(symbol)) {
        this.chapters_range_map[map_key] = value_range_array[0];
        if (symbol == "-") {
          this.chapters_range_map[this.chapters_lte] = value_range_array[1];
        }
        this.add_url_chapter_request();
      }
    };
    update_chapters_range_map("<", this.chapters_lte);
    update_chapters_range_map(">", this.chapters_gte);
    update_chapters_range_map("-", this.chapters_gte);
  }

  add_url_chapter_request() {
    const separator = this.url.includes("?") ? "&" : "?";
    localStorage.setItem("last_url_search", this.url_search);

    if (!this.url_search.includes(this.chapters_gte)) {
      window.location.href += `${separator}${this.chapters_gte}=${
        this.chapters_range_map[this.chapters_gte]
      }&${this.chapters_lte}=${this.chapters_range_map[this.chapters_lte]}`;
      return;
    }
    this.url_chapters_replace();
  }

  url_chapters_replace() {
    let old_value_chapters_gte = String();
    let old_value_chapters_lte = String();

    for (let url_part of this.url_search.split("&")) {
      if (url_part.includes(this.chapters_gte)) {
        old_value_chapters_gte = url_part.slice(url_part.indexOf("=") + 1);
        this.call_change_chapters_range_map_logic(
          this.chapters_gte,
          old_value_chapters_gte
        );
      }
      if (url_part.includes(this.chapters_lte)) {
        old_value_chapters_lte = url_part.slice(url_part.indexOf("=") + 1);
        this.call_change_chapters_range_map_logic(
          this.chapters_lte,
          old_value_chapters_lte
        );
      }
    }

    window.location.href = this.url
      .replace(
        `${this.chapters_lte}=${old_value_chapters_lte}`,
        `${this.chapters_lte}=${this.chapters_range_map[this.chapters_lte]}`
      )
      .replace(
        `${this.chapters_gte}=${old_value_chapters_gte}`,
        `${this.chapters_gte}=${this.chapters_range_map[this.chapters_gte]}`
      );
  }

  call_change_chapters_range_map_logic(chapters_type, old_value_chapters_type) {
    let values_compare = Boolean();
    if (chapters_type == this.chapters_gte) {
      values_compare =
        Number(old_value_chapters_type) <
        Number(this.chapters_range_map[chapters_type]);
    } else {
      values_compare =
        Number(old_value_chapters_type) >
        Number(this.chapters_range_map[chapters_type]);
    }
    this.change_chapters_range_map_logic(
      chapters_type,
      old_value_chapters_type,
      values_compare
    );
  }

  change_chapters_range_map_logic(
    chapters_type,
    old_value_chapters_type,
    values_compare
  ) {
    if (!old_value_chapters_type) {
      this.chapters_range_map[chapters_type] = String();
    }
    if (old_value_chapters_type == this.chapters_range_map[chapters_type]) {
      this.chapters_range_map[chapters_type] = String();
    }
    if (values_compare) {
      if (this.chapters_range_map[chapters_type] !== String()) {
        this.chapters_range_map[chapters_type] = old_value_chapters_type;
      }
    }
  }
}
