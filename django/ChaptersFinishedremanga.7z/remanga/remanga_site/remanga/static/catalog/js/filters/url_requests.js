class Url_requests {
  constructor(get_elements, type_name, input_number) {
    this.get_elements = get_elements;
    this.type_name = type_name;
    this.input_number = input_number;
    this.get_elements();
    this.init_url_vars();
  }
  // chapters_filters

  init_url_vars() {
    this.url = window.location.href;
    this.url_search = window.location.search.replace("?", "");
    this.is_url_replace_value = false;
    this.url_params = [
      "issue_year_gte",
      "issue_year_lte",
      "rating_gte",
      "rating_lte",
    ];
    this.chapters_gte = "count_chapters_gte";
    this.chapters_lte = "count_chapters_lte";
    this.chapters_range_map = {
      [this.chapters_gte]: "",
      [this.chapters_lte]: "",
    };
  }
  //
  // dropmenu_filters

  delete_filter(event, filter_data, value_key) {
    this.get_elements();
    let clicked_div_label = this.div_label.innerHTML.includes(
      event.target.parentNode.innerHTML
    );
    let label_class = ".jsx-9f9056eddaf3b30b";
    let label_text =
      event.target.parentNode.querySelector(label_class).innerText;

    if (clicked_div_label) {
      for (let text_index = 0; text_index < filter_data.length; text_index++) {
        if (filter_data[text_index][value_key] == label_text) {
          this.call_url_remove_requests(text_index);
        }
      }
    }
  }

  url_remove_requests(text_index, separator_before, separator_after) {
    window.location.href = this.url.replace(
      `${separator_before}${this.type_name}=${text_index}${separator_after}`,
      ""
    );
  }

  call_url_remove_requests(text_index) {
    if (
      this.url.indexOf(`${this.type_name}=${text_index}`) !=
      this.url.indexOf("?") + 1
    ) {
      this.url_remove_requests(text_index, "&", "");
      return;
    }

    if (this.url.includes("&")) {
      this.url_remove_requests(text_index, "", "&");
    } else {
      this.url_remove_requests(text_index, "?", "");
    }
  }

  listen_span_click() {
    this.get_elements();

    if (this.div_input.querySelector(this.filter_menu_class)) {
      this.all_filter_span.map((span) => {
        span.addEventListener("click", () => {
          var clicked_span = this.all_filter_span.indexOf(span);
          this.add_url_request(this.type_name, clicked_span);
        });
      });
    }
  }

  add_url_request(name, value) {
    const separator = this.url.includes("?") ? "&" : "?";

    for (let url_part of this.url_search.split("&")) {
      if (url_part == `${name}=${value}`) {
        return;
      }

      for (let url_param of this.url_params) {
        this.url_replace_value(url_part, url_param, name, value);
      }
    }
    this.before_window_reload();

    if (this.is_url_replace_value) {
      return;
    }

    window.location.href += `${separator}${name}=${value}`;
  }
  //
  // input_range_filters

  url_replace_value(url_part, url_param, name, value) {
    if (url_part.includes(url_param) && name == url_param) {
      let old_value = url_part.slice(url_part.indexOf("=") + 1);
      window.location.href = this.url.replace(
        `${name}=${old_value}`,
        `${name}=${value}`
      );
      this.is_url_replace_value = true;
    }
  }

  listen_input_range() {
    let inputs = [...document.querySelectorAll(".Input_input__F9Zao")];
    for (let input of inputs) {
      input.addEventListener("keyup", (event) => {
        let index_clicked_input = inputs.indexOf(event.target);

        // setTimeout(() => {
        this.add_url_request(this.url_params[index_clicked_input], input.value);
        // }, 1000);
      });
    }
  }
  //
  // chapters_filters

  listen_chapters_spans() {
    const chapters_spans = [...document.querySelectorAll(".Chip_chip__cpsxK")];
    for (const chapter_span of chapters_spans) {
      chapter_span.addEventListener("click", (event) => {
        const clicked_text = event.target.innerText;

        new Url_requests_chapters(
          this.init_url_vars
        ).call_add_url_chapter_request(clicked_text);
      });
    }
  }
  //
  before_window_reload() {
    this.get_elements();
    if (this.filter_menu) {
      localStorage.setItem("input_number", this.input_number);
      localStorage.setItem("div_span_scroll", this.filter_menu.scrollTop);
    }

    localStorage.setItem("last_url_search", this.url_search);
  }
}
